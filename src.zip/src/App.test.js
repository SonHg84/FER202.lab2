import { fireEvent, render, screen, within, waitFor } from '@testing-library/react';
import App from './App';
import { movies } from './data/movies';

beforeEach(() => window.localStorage.clear());

test('shows actual movie data and combines title search with genre filtering', () => {
  render(<App />);
  expect(screen.getByRole('heading', { name: 'Mini Movie Manager' })).toBeInTheDocument();
  expect(screen.getAllByRole('listitem')).toHaveLength(6);
  expect(screen.getByRole('button', { name: 'Xem chi tiết Interstellar' })).toHaveTextContent('2014');
  fireEvent.change(screen.getByLabelText('Tìm tên phim'), { target: { value: '  THE  ' } });
  expect(screen.getAllByRole('listitem')).toHaveLength(2);
  fireEvent.change(screen.getByLabelText('Thể loại'), { target: { value: 'Action' } });
  expect(screen.getAllByRole('listitem')).toHaveLength(1);
  expect(screen.getByRole('status')).toHaveTextContent('Tổng: 6Yêu thích: 0Đang hiển thị: 1');
  fireEvent.change(screen.getByLabelText('Tìm tên phim'), { target: { value: 'unknown' } });
  expect(screen.getByText('Không tìm thấy phim')).toBeInTheDocument();
  expect(screen.getByRole('status')).toHaveTextContent('Đang hiển thị: 0');
});

test('sorts by title, year and rating, and restores the default data order', () => {
  render(<App />);
  const sort = screen.getByLabelText('Sắp xếp');
  fireEvent.change(sort, { target: { value: 'title' } });
  expect(screen.getAllByRole('listitem')[0]).toHaveTextContent('Interstellar');
  expect(screen.getAllByRole('listitem')[1]).toHaveTextContent('Parasite');
  fireEvent.change(sort, { target: { value: 'year' } });
  expect(screen.getAllByRole('listitem')[0]).toHaveTextContent('Parasite');
  fireEvent.change(sort, { target: { value: 'rating' } });
  expect(screen.getAllByRole('listitem')[0]).toHaveTextContent('The Dark Knight');
  fireEvent.change(sort, { target: { value: 'default' } });
  screen.getAllByRole('listitem').forEach((row, index) => expect(row).toHaveTextContent(movies[index].title));
});

test('persists favorites and counts them independently of visible movies', () => {
  const { unmount } = render(<App />);
  fireEvent.click(screen.getByRole('button', { name: 'Yêu thích Interstellar' }));
  expect(screen.getByRole('button', { name: 'Bỏ yêu thích Interstellar' })).toHaveAttribute('aria-pressed', 'true');
  expect(JSON.parse(window.localStorage.getItem('mini-movie-manager-favorites'))).toEqual([1]);
  fireEvent.change(screen.getByLabelText('Thể loại'), { target: { value: 'Drama' } });
  expect(screen.getByRole('status')).toHaveTextContent('Yêu thích: 1Đang hiển thị: 1');
  unmount();
  render(<App />);
  fireEvent.click(screen.getByRole('button', { name: 'Bỏ yêu thích Interstellar' }));
  expect(screen.getByRole('status')).toHaveTextContent('Yêu thích: 0');
});

test('opens every data field in the modal, closes it, and restores focus', async () => {
  render(<App />);
  const trigger = screen.getByRole('button', { name: 'Movie detail: Interstellar' });
  trigger.focus();
  fireEvent.click(trigger);
  const dialog = await screen.findByRole('dialog', { name: 'Movie detail' });
  expect(dialog.querySelectorAll('dt')).toHaveLength(8);
  for (const value of ['1', 'Interstellar', 'Sci-Fi', '2014', '8.7/10', 'Christopher Nolan', '169 phút', movies[0].description]) {
    expect(within(dialog).getByText(value, { exact: true })).toBeInTheDocument();
  }
  fireEvent.click(within(dialog).getByRole('button', { name: 'Close' }));
  await waitFor(() => expect(screen.queryByRole('dialog')).not.toBeInTheDocument());
  expect(trigger).toHaveFocus();
  fireEvent.click(screen.getByRole('button', { name: 'Xem chi tiết Parasite' }));
  const nextDialog = await screen.findByRole('dialog');
  expect(within(nextDialog).getByText('Bong Joon-ho')).toBeInTheDocument();
  fireEvent.keyDown(nextDialog, { key: 'Escape', code: 'Escape', keyCode: 27 });
  await waitFor(() => expect(screen.queryByRole('dialog')).not.toBeInTheDocument());
});

test('persists the theme and applies it to movie details', async () => {
  const { container, unmount } = render(<App />);
  fireEvent.click(screen.getByRole('button', { name: 'Chuyển sang giao diện tối' }));
  expect(container.querySelector('.app')).toHaveAttribute('data-theme', 'dark');
  unmount();
  render(<App />);
  expect(screen.getByRole('button', { name: 'Chuyển sang giao diện sáng' })).toHaveTextContent('Light');
  fireEvent.click(screen.getByRole('button', { name: 'Xem chi tiết Interstellar' }));
  expect(await screen.findByRole('dialog')).toHaveAttribute('data-bs-theme', 'dark');
});
