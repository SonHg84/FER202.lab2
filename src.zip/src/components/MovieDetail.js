import { Fragment, useContext } from 'react';
import Modal from 'react-bootstrap/Modal';
import { ThemeContext } from '../context/ThemeContext';

function MovieDetail({ movie, onClose }) {
  const { darkMode } = useContext(ThemeContext);

  return (
    <Modal show={Boolean(movie)} onHide={onClose} centered className="movie-detail" data-bs-theme={darkMode ? 'dark' : 'light'} aria-labelledby="movie-detail-title">
      <Modal.Header>
        <Modal.Title id="movie-detail-title">Movie detail</Modal.Title>
      </Modal.Header>
      {movie && (
        <Modal.Body>
          <dl className="movie-detail-fields">
            {Object.entries(movie).map(([field, value]) => (
              <Fragment key={field}>
                <dt>{field}</dt><dd>{String(value)}</dd>
              </Fragment>
            ))}
          </dl>
        </Modal.Body>
      )}
      <Modal.Footer>
        <button type="button" className="close-button" onClick={onClose}>Close</button>
      </Modal.Footer>
    </Modal>
  );
}

export default MovieDetail;
